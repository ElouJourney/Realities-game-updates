#===============================================================================
# ** Interpreter
#-------------------------------------------------------------------------------
#  This interpreter runs event commands. This class is used within the
#  Game_System class and the Game_Event class.
#===============================================================================
class Interpreter
  #-----------------------------------------------------------------------------
  # * Object Initialization
  #     depth : nest depth
  #     main  : main flag
  #-----------------------------------------------------------------------------
  def initialize(depth = 0, main = false)
    @depth = depth
    @main  = main
    if depth > 100
      print("Common event call has exceeded maximum limit.")
      exit
    end
    clear
  end

  def inspect
    str = super.chop
    str << sprintf(" @event_id: %d>", @event_id)
    return str
  end

  def clear
    @map_id             = 0       # map ID when starting up
    @event_id           = 0       # event ID
    @message_waiting    = false   # waiting for message to end
    @move_route_waiting = false   # waiting for move completion
    @wait_count         = 0       # wait count
    @child_interpreter  = nil     # child interpreter
    @branch             = {}      # branch data
    @buttonInput        = false
    @hidden_choices     = []
    @renamed_choices    = []
    end_follower_overrides
  end
  #-----------------------------------------------------------------------------
  # * Event Setup
  #     list     : list of event commands
  #     event_id : event ID
  #-----------------------------------------------------------------------------
  def setup(list, event_id, map_id = nil)
    clear
    @map_id = map_id || $game_map.map_id
    @event_id = event_id
    @list = list
    @index = 0
    @branch.clear
  end

  def setup_starting_event
    $game_map.refresh if $game_map.need_refresh
    # Set up common event if one wants to start
    if $game_temp.common_event_id > 0
      setup($data_common_events[$game_temp.common_event_id].list, 0)
      $game_temp.common_event_id = 0
      return
    end
    # Check all map events for one that wants to start, and set it up
    $game_map.events.each_value do |event|
      next if !event.starting
      if event.trigger < 3   # Isn't autorun or parallel processing
        event.lock
        event.clear_starting
      end
      setup(event.list, event.id, event.map.map_id)
      return
    end
    # Check all common events for one that is autorun, and set it up
    $data_common_events.compact.each do |common_event|
      next if common_event.trigger != 1 || !$game_switches[common_event.switch_id]
      setup(common_event.list, 0)
      return
    end
  end

  def running?
    return !@list.nil?
  end
  #-----------------------------------------------------------------------------
  # * Frame Update
  #-----------------------------------------------------------------------------
  def update
    @loop_count = 0
    loop do
      @loop_count += 1
      if @loop_count > 100   # Call Graphics.update for freeze prevention
        Graphics.update
        @loop_count = 0
      end
      # If this interpreter's map isn't the current map or connected to it,
      # forget this interpreter's event ID
      if $game_map.map_id != @map_id && !$map_factory.areConnected?($game_map.map_id, @map_id)
        @event_id = 0
      end
      # Update child interpreter if one exists
      if @child_interpreter
        @child_interpreter.update
        @child_interpreter = nil if !@child_interpreter.running?
        return if @child_interpreter
      end
      # Do nothing if a message is being shown
      return if @message_waiting
      # Do nothing if any event or the player is in the middle of a move route
      if @move_route_waiting
        return if $game_player.move_route_forcing
        $game_map.events.each_value do |event|
          echoln event.id if event.move_route_forcing
          return if event.move_route_forcing
        end
        $game_temp.followers.each_follower do |event, follower|
          return if event.move_route_forcing
        end
        @move_route_waiting = false
      end
      # Do nothing while waiting
      if @wait_count > 0
        @wait_count -= 1
        return
      end
      # Do nothing if the pause menu is going to open
      return if $game_temp.menu_calling
      # If there are no commands in the list, try to find something that wants to run
      if @list.nil?
        setup_starting_event if @main
        return if @list.nil?   # Couldn't find anything that wants to run
      end
      # Execute the next command
      return if execute_command == false
      # Move to the next @index
      @index += 1
    end
  end
  #-----------------------------------------------------------------------------
  # * Execute script
  #-----------------------------------------------------------------------------
  def execute_script(script)
    return nil if script.nil? || script.empty?
    
    begin
      result = eval(script)
      return result
    rescue Exception => e
      raise if e.is_a?(SystemExit) || e.class.to_s == "Reset"
      
      puts "DEBUG: Script error occurred - attempting to log..."
      
      log_script_error(e, script)
      
      error_message = build_error_message(e, script)
      raise EventScriptError.new(error_message)
    end
  end
  
  def debug_mode?
   debug_states = {
      "$DEBUG" => $DEBUG,
      "$TEST" => defined?($TEST) && $TEST,
      "DEBUG constant" => defined?(DEBUG) && DEBUG,
      "Game Switches" => $game_switches && ($game_switches[DEBUG_SWITCH] rescue false),
      "Console" => defined?(PBDebug) && PBDebug.isConsole?,
      "Battle Debug" => defined?(PBDebug) && PBDebug.isBattleDebug?
    }
  
    debug_states.values.any?
  end

  def get_debug_details
    details = {
     "Debug Mode Overall" => debug_mode? ? "ENABLED" : "DISABLED",
      "$DEBUG" => $DEBUG ? "TRUE" : "FALSE",
    "$TEST" => (defined?($TEST) && $TEST) ? "TRUE" : "FALSE"
  }
  
   details["Game Version"] = Settings::GAME_VERSION rescue "Unknown"
   details["Essentials Version"] = Essentials::VERSION rescue "Unknown"
   details["Game Title"] = System.game_title rescue "Unknown"
  
    details["Platform"] = System.platform rescue "Unknown"
  
    return details
  end
  
  def log_script_error(exception, script)
  begin
    puts "DEBUG: Starting error logging process..."
    
    current_dir = Dir.pwd
    puts "DEBUG: Current directory: #{current_dir}"
    
    logs_dir = "Logs"
    puts "DEBUG: Checking for logs directory: #{logs_dir}"
    
    if !Dir.exist?(logs_dir)
      puts "DEBUG: Logs directory doesn't exist, creating..."
      Dir.mkdir(logs_dir)
      puts "DEBUG: Logs directory created successfully"
    else
      puts "DEBUG: Logs directory already exists"
    end
    
    error_log = File.join(logs_dir, "ScriptErrors.log")
    puts "DEBUG: Log file path: #{error_log}"
    
    puts "DEBUG: Testing write permissions..."
    test_file = File.join(logs_dir, "test_write.tmp")
    File.open(test_file, 'w') { |f| f.puts "test" }
    File.delete(test_file) if File.exist?(test_file)
    puts "DEBUG: Write permissions OK"
    
    puts "DEBUG: Opening log file for writing..."
    File.open(error_log, 'a') do |file|
      puts "DEBUG: Successfully opened log file"
      
      file.puts "=" * 80
      file.puts "SCRIPT ERROR - #{Time.now.strftime('%Y-%m-%d %H:%M:%S')}"
      file.puts "=" * 80
      
      file.puts "\n--- DEBUG & SYSTEM INFORMATION ---"
      debug_details = get_debug_details
      debug_details.each do |key, value|
        file.puts "#{key}: #{value}"
      end
      
      if debug_mode?
        file.puts "\n--- DEBUG CONTEXT ---"
        file.puts "Current Scene: #{Kernel.pbGetCurrentScene rescue 'Unknown'}"
        file.puts "Player Name: #{$player&.name || 'Unknown'}"
        file.puts "Play Time: #{pbGetPlayTimeString rescue 'Unknown'}"
        
        if $game_switches && $game_variables
          file.puts "Recent Switches (last 10):"
          recent_switches = $game_switches.instance_variable_get(:@data).to_a.last(10)
          recent_switches.each_with_index do |value, index|
            switch_id = $game_switches.instance_variable_get(:@data).size - 10 + index
            file.puts "  Switch[#{switch_id}]: #{value}" if switch_id >= 0
          end
          
          file.puts "Recent Variables (last 5):"
          recent_vars = $game_variables.instance_variable_get(:@data).to_a.last(5)
          recent_vars.each_with_index do |value, index|
            var_id = $game_variables.instance_variable_get(:@data).size - 5 + index
            file.puts "  Variable[#{var_id}]: #{value}" if var_id >= 0 && value != 0
          end
        end
      end
      
      # Basic error info
      file.puts "\n--- ERROR DETAILS ---"
      file.puts "Exception: #{exception.class}"
      file.puts "Message: #{exception.message}"
      
      # Location context
      file.puts "\n--- LOCATION CONTEXT ---"
      file.puts "Map ID: #{@map_id}"
      file.puts "Map Name: #{($game_map&.name rescue 'Unknown')}"
      file.puts "Event ID: #{@event_id}"
      
      if @event_id > 0
        event = get_self
        if event
          file.puts "Event Coordinates: (#{event.x}, #{event.y})"
          file.puts "Event Name: #{event.name}" if event.respond_to?(:name)
        end
      else
        file.puts "Event Type: Common Event"
      end
        
        # Script content with line numbers
        file.puts "\n--- SCRIPT CONTEXT ---"
        if script.length > 1000
          file.puts "Script (first 1000 chars):"
          script[0..1000].split("\n").each_with_index do |line, i|
            file.puts "#{i+1}: #{line}"
          end
          file.puts "... (truncated, full script too long)"
        else
          file.puts "Full Script:"
          script.split("\n").each_with_index do |line, i|
            file.puts "#{i+1}: #{line}"
          end
        end
        
        # Backtrace
        file.puts "\n--- BACKTRACE (first 15 lines) ---"
        if exception.backtrace
          exception.backtrace[0..14].each do |line|
            # Convert RGSS section numbers to script names if possible
            converted_line = line.gsub(/Section(\d+)/) do
              section_num = $1.to_i
              if $RGSS_SCRIPTS && $RGSS_SCRIPTS[section_num]
                "\"#{$RGSS_SCRIPTS[section_num][1]}\""
              else
                "Section#{section_num}"
              end
            end
            file.puts converted_line
          end
        else
          file.puts "No backtrace available"
        end
        
        # Interpreter state
        file.puts "\n--- INTERPRETER STATE ---"
        file.puts "Current Index: #{@index}"
        file.puts "List Size: #{@list&.length || 'nil'}"
        file.puts "Main Interpreter: #{@main}"
        file.puts "Depth: #{@depth}"
        file.puts "Message Waiting: #{@message_waiting}"
        file.puts "Move Route Waiting: #{@move_route_waiting}"
        file.puts "Wait Count: #{@wait_count}"
        
        # Current command context
        if @list && @index && @index < @list.length
          current_cmd = @list[@index]
          file.puts "Current Command Code: #{current_cmd.code}"
          file.puts "Current Command Params: #{current_cmd.parameters.inspect}"
          
          # Add surrounding commands for context
          file.puts "\n--- SURROUNDING COMMANDS ---"
          start_idx = [(@index || 0) - 2, 0].max
          end_idx = [(@index || 0) + 2, @list.length - 1].min
          (start_idx..end_idx).each do |i|
            cmd = @list[i]
            marker = i == @index ? ">>> " : "    "
            file.puts "#{marker}#{i}: Code #{cmd.code}, Params: #{cmd.parameters.inspect}"
          end
        end
        
        # Player/game state for additional context
        file.puts "\n--- GAME STATE ---"
        file.puts "Player Position: (#{$game_player&.x || '?'}, #{$game_player&.y || '?'})"
        file.puts "Player Direction: #{$game_player&.direction || '?'}"
        file.puts "In Battle: #{$game_temp&.in_battle || false}"
        file.puts "Menu Calling: #{$game_temp&.menu_calling || false}"
        
        file.puts "=" * 80
        file.puts "\n"
        
        file.flush  # Force write to disk
        puts "DEBUG: Successfully wrote to log file"
      end
      
      puts "DEBUG: Log file closed successfully"
      
      # Verify the file was actually created and has content
      if File.exist?(error_log)
        file_size = File.size(error_log)
        puts "DEBUG: Log file exists and is #{file_size} bytes"
        puts "Script error logged to: #{File.expand_path(error_log)}"
      else
        puts "DEBUG: ERROR - Log file was not created!"
      end
      
      puts "Error: #{exception.class}: #{exception.message}"
      
    rescue => logging_error
      # If logging fails, show detailed info about why
      puts "ERROR: Failed to log script error!"
      puts "Logging error: #{logging_error.class}: #{logging_error.message}"
      puts "Logging error backtrace:"
      logging_error.backtrace[0..5].each { |line| puts "  #{line}" } if logging_error.backtrace
      puts ""
      puts "Original script error: #{exception.class}: #{exception.message}"
    end
  end

  def build_error_message(exception, script)
    event = get_self
    map_name = ($game_map&.name rescue nil) || "Unknown Map"
    
    # Build the main error header
    message_parts = []
    
    # Location information with better formatting
    if @event_id > 0 && event
      message_parts << "━━━ SCRIPT ERROR IN EVENT ━━━"
      message_parts << "Event: ##{@event_id} at position (#{event.x}, #{event.y})"
      message_parts << "Map: ##{$game_map.map_id} (#{map_name})"
      if event.respond_to?(:name) && !event.name.empty?
        message_parts << "Event Name: #{event.name}"
      end
    else
      message_parts << "━━━ SCRIPT ERROR IN COMMON EVENT ━━━"
      message_parts << "Map: ##{$game_map.map_id} (#{map_name})"
    end
    
    # Error details
    message_parts << ""
    message_parts << "Exception: #{exception.class}"
    message_parts << "Message: #{exception.message}"
    
    # Script preview with line numbers for syntax errors
    message_parts << ""
    message_parts << "Script Content:"
    if script.length > 300
      script_lines = script[0..300].split("\n")
      script_lines.each_with_index do |line, i|
        message_parts << "#{i+1}: #{line}"
      end
      message_parts << "... (truncated - full script logged to Logs/ScriptErrors.log)"
    else
      script.split("\n").each_with_index do |line, i|
        message_parts << "#{i+1}: #{line}"
      end
    end
    
    # Enhanced syntax error hints
    if exception.is_a?(SyntaxError)
      message_parts << ""
      message_parts << "━━━ SYNTAX ERROR TIPS ━━━"
      script.split("\n").each_with_index do |line, line_num|
        line = line.gsub(/\s+$/, "")
        
        # Check for common syntax issues
        if line[/^\s*\(/]
          message_parts << "⚠ Line #{line_num + 1}: Starts with '(' - try moving to end of previous line"
        end
        if line[/\=\s*\&/]
          message_parts << "⚠ Line #{line_num + 1}: Has '= &' - check method arguments"
        end
        if line[/\w+\s+\(/] && !line[/def\s+\w+\s*\(/]
          message_parts << "⚠ Line #{line_num + 1}: Space before '(' - remove the space"
        end
        if line[/end\s*$/] && line_num == 0
          message_parts << "⚠ Line #{line_num + 1}: Starts with 'end' - missing opening statement?"
        end
      end
    elsif exception.is_a?(NoMethodError)
      message_parts << ""
      message_parts << "━━━ METHOD ERROR TIPS ━━━"
      message_parts << "• Check spelling of method names"
      message_parts << "• Verify the object supports this method"
      message_parts << "• Check if variables are properly initialized"
    elsif exception.is_a?(NameError)
      message_parts << ""
      message_parts << "━━━ NAME ERROR TIPS ━━━"
      message_parts << "• Check spelling of variable/constant names"
      message_parts << "• Verify variables are defined before use"
      message_parts << "• Check for typos in class/module names"
    end
    
    # Backtrace
    if exception.backtrace
      message_parts << ""
      message_parts << "━━━ CALL STACK ━━━"
      relevant_trace = exception.backtrace.select { |line| 
        line.include?('Section') || line.include?('eval') 
      }[0..3]
      
      if relevant_trace.any?
        relevant_trace.each do |line|
          # Convert section numbers to script names
          converted_line = line.gsub(/Section(\d+)/) do
            section_num = $1.to_i
            if $RGSS_SCRIPTS && $RGSS_SCRIPTS[section_num]
              "#{$RGSS_SCRIPTS[section_num][1]}"
            else
              "Section#{section_num}"
            end
          end
          message_parts << converted_line
        end
      else
        message_parts << exception.backtrace[0..2].join("\n")
      end
    end
    
    message_parts << ""
    message_parts << "Check console output for logging details"
    
    message_parts.join("\n")
  end
  
  #-----------------------------------------------------------------------------
  # * Get Character
  #     parameter : parameter
  #-----------------------------------------------------------------------------
  def get_character(parameter = 0)
    case parameter
    when -1   # player
      return $game_player
    when 0    # this event
      events = $game_map.events
      return (events) ? events[@event_id] : nil
    else      # specific event
      events = $game_map.events
      return (events) ? events[parameter] : nil
    end
  end

  def get_player
    return get_character(-1)
  end

  def get_self
    return get_character(0)
  end

  def get_event(parameter)
    return get_character(parameter)
  end
  #-----------------------------------------------------------------------------
  # * Freezes all events on the map (for use at the beginning of common events)
  #-----------------------------------------------------------------------------
  def pbGlobalLock
    $game_map.events.each_value { |event| event.minilock }
  end
  #-----------------------------------------------------------------------------
  # * Unfreezes all events on the map (for use at the end of common events)
  #-----------------------------------------------------------------------------
  def pbGlobalUnlock
    $game_map.events.each_value { |event| event.unlock }
  end
  #-----------------------------------------------------------------------------
  # * Gets the next index in the interpreter, ignoring certain commands between messages
  #-----------------------------------------------------------------------------
  def pbNextIndex(index)
    return -1 if !@list || @list.length == 0
    i = index + 1
    loop do
      return i if i >= @list.length - 1
      case @list[i].code
      when 118, 108, 408   # Label, Comment
        i += 1
      when 413             # Repeat Above
        i = pbRepeatAbove(i)
      when 113             # Break Loop
        i = pbBreakLoop(i)
      when 119             # Jump to Label
        newI = pbJumpToLabel(i, @list[i].parameters[0])
        i = (newI > i) ? newI : i + 1
      else
        return i
      end
    end
  end

  def pbRepeatAbove(index)
    index = @list[index].indent
    loop do
      index -= 1
      return index + 1 if @list[index].indent == indent
    end
  end

  def pbBreakLoop(index)
    indent = @list[index].indent
    temp_index = index
    loop do
      temp_index += 1
      return index + 1 if temp_index >= @list.size - 1
      return temp_index + 1 if @list[temp_index].code == 413 &&
                               @list[temp_index].indent < indent
    end
  end

  def pbJumpToLabel(index, label_name)
    temp_index = 0
    loop do
      return index + 1 if temp_index >= @list.size - 1
      return temp_index + 1 if @list[temp_index].code == 118 &&
                               @list[temp_index].parameters[0] == label_name
      temp_index += 1
    end
  end

  def follower_move_route(id = nil)
    @follower_move_route = true
    @follower_move_route_id = id
  end

  def follower_animation(id = nil)
    @follower_animation = true
    @follower_animation_id = id
  end

  def end_follower_overrides
    @follower_move_route = false
    @follower_move_route_id = nil
    @follower_animation = false
    @follower_animation_id = nil
  end

  #-----------------------------------------------------------------------------
  # * Various methods to be used in a script event command.
  #-----------------------------------------------------------------------------
  # Helper function that shows a picture in a script.
  def pbShowPicture(number, name, origin, x, y, zoomX = 100, zoomY = 100, opacity = 255, blendType = 0)
    number += ($game_temp.in_battle ? 50 : 0)
    $game_screen.pictures[number].show(name, origin, x, y, zoomX, zoomY, opacity, blendType)
  end

  # Erases an event and adds it to the list of erased events so that
  # it can stay erased when the game is saved then loaded again.
  def pbEraseThisEvent
    if $game_map.events[@event_id]
      $game_map.events[@event_id].erase
      $PokemonMap&.addErasedEvent(@event_id)
    end
    @index += 1
    return true
  end

  # Runs a common event.
  def pbCommonEvent(id)
    common_event = $data_common_events[id]
    return if !common_event
    if $game_temp.in_battle
      $game_system.battle_interpreter.setup(common_event.list, 0)
    else
      interp = Interpreter.new
      interp.setup(common_event.list, 0)
      loop do
        Graphics.update
        Input.update
        interp.update
        pbUpdateSceneMap
        break if !interp.running?
      end
    end
  end

  # Sets another event's self switch (eg. pbSetSelfSwitch(20, "A", true) ).
  def pbSetSelfSwitch(eventid, switch_name, value, mapid = -1)
    mapid = @map_id if mapid < 0
    old_value = $game_self_switches[[mapid, eventid, switch_name]]
    $game_self_switches[[mapid, eventid, switch_name]] = value
    if value != old_value && $map_factory.hasMap?(mapid)
      $map_factory.getMap(mapid, false).need_refresh = true
    end
  end

  def tsOff?(c)
    return get_self.tsOff?(c)
  end
  alias isTempSwitchOff? tsOff?

  def tsOn?(c)
    return get_self.tsOn?(c)
  end
  alias isTempSwitchOn? tsOn?

  def setTempSwitchOn(c)
    get_self.setTempSwitchOn(c)
  end

  def setTempSwitchOff(c)
    get_self.setTempSwitchOff(c)
  end

  def getVariable(*arg)
    if arg.length == 0
      return nil if !$PokemonGlobal.eventvars
      return $PokemonGlobal.eventvars[[@map_id, @event_id]]
    else
      return $game_variables[arg[0]]
    end
  end

  def setVariable(*arg)
    if arg.length == 1
      $PokemonGlobal.eventvars = {} if !$PokemonGlobal.eventvars
      $PokemonGlobal.eventvars[[@map_id, @event_id]] = arg[0]
    else
      $game_variables[arg[0]] = arg[1]
      $game_map.need_refresh = true
    end
  end

  def pbGetPokemon(id)
    return $player.party[pbGet(id)]
  end

  def pbSetEventTime(*arg)
    $PokemonGlobal.eventvars = {} if !$PokemonGlobal.eventvars
    time = pbGetTimeNow
    time = time.to_i
    pbSetSelfSwitch(@event_id, "A", true)
    $PokemonGlobal.eventvars[[@map_id, @event_id]] = time
    arg.each do |otherevt|
      pbSetSelfSwitch(otherevt, "A", true)
      $PokemonGlobal.eventvars[[@map_id, otherevt]] = time
    end
  end

  # Used in boulder events. Allows an event to be pushed.
  def pbPushThisEvent
    event = get_self
    old_x  = event.x
    old_y  = event.y
    # Apply strict version of passable, which treats tiles that are passable
    # only from certain directions as fully impassible
    return if !event.can_move_in_direction?($game_player.direction, true)
    $stats.strength_push_count += 1
    case $game_player.direction
    when 2 then event.move_down
    when 4 then event.move_left
    when 6 then event.move_right
    when 8 then event.move_up
    end
    $PokemonMap&.addMovedEvent(@event_id)
    if old_x != event.x || old_y != event.y
      $game_player.lock
      loop do
        Graphics.update
        Input.update
        pbUpdateSceneMap
        break if !event.moving?
      end
      $game_player.unlock
    end
  end

  def pbPushThisBoulder
    pbPushThisEvent if $PokemonMap.strengthUsed
    return true
  end

  def pbSmashThisEvent
    event = get_self
    pbSmashEvent(event) if event
    @index += 1
    return true
  end

  def pbTrainerIntro(symbol)
    return true if $DEBUG && !GameData::TrainerType.exists?(symbol)
    tr_type = GameData::TrainerType.get(symbol).id
    pbGlobalLock
    pbPlayTrainerIntroBGM(tr_type)
    return true
  end

  def pbTrainerEnd
    pbGlobalUnlock
    event = get_self
    event&.erase_route
  end

  def setPrice(item, buy_price = -1, sell_price = -1)
    item = GameData::Item.get(item).id
    $game_temp.mart_prices[item] = [-1, -1] if !$game_temp.mart_prices[item]
    $game_temp.mart_prices[item][0] = buy_price if buy_price > 0
    if sell_price >= 0   # 0=can't sell
      $game_temp.mart_prices[item][1] = sell_price * 2
    elsif buy_price > 0
      $game_temp.mart_prices[item][1] = buy_price
    end
  end

  def setSellPrice(item, sell_price)
    setPrice(item, -1, sell_price)
  end
end
