#===============================================================================
# class Object
#===============================================================================
class Object
  alias full_inspect inspect unless method_defined?(:full_inspect)

  def inspect
    return "#<#{self.class}>"
  end
end

#===============================================================================
# class Class
#===============================================================================
class Class
  def to_sym
    return self.to_s.to_sym
  end
end

#===============================================================================
# class String
#===============================================================================
class String
  def starts_with_vowel?
    return ["a", "e", "i", "o", "u"].include?(self[0, 1].downcase)
  end

  def first(n = 1); return self[0...n]; end

  def last(n = 1); return self[-n..-1] || self; end

  def blank?; return self.strip.empty?; end

  def cut(bitmap, width)
    string = self
    width -= bitmap.text_size("...").width
    string_width = 0
    text = []
    string.scan(/./).each do |char|
      wdh = bitmap.text_size(char).width
      next if (wdh + string_width) > width
      string_width += wdh
      text.push(char)
    end
    text.push("...") if text.length < string.length
    new_string = ""
    text.each do |char|
      new_string += char
    end
    return new_string
  end

  def numeric?
    return !self[/^[+-]?([0-9]+)(?:\.[0-9]+)?$/].nil?
  end

#=============================================================================
# NEW METHODS
#=============================================================================
  def safe_cut(bitmap, width, fallback = "...")
    return fallback if self.empty? || width <= 0
    return self if bitmap.nil?
    
    begin
      result = self.cut(bitmap, width)
      # Ensure we don't return nil
      result.nil? ? fallback : result
    rescue StandardError => e
      # Log the error for debugging if you have a logger
      char_width = bitmap&.text_size("W")&.width || 8
      max_chars = [width / char_width, 1].max
      self.length > max_chars ? self[0...max_chars] + fallback : self
    end
  end

  def to_pokemon_case
    result = self.dup
    
    # Case-insensitive replacements that preserve original casing
    result.gsub!(/pokemon/i) { |match| match.downcase == match ? "Pokémon" : "POKÉMON" }
    result.gsub!(/pokedex/i) { |match| match.downcase == match ? "Pokédex" : "POKÉDEX" }
    result.gsub!(/pokeball/i) { |match| match.downcase == match ? "Poké Ball" : "POKÉ BALL" }
    result.gsub!(/poke\s*ball/i) { |match| match.downcase == match ? "Poké Ball" : "POKÉ BALL" }
    result.gsub!(/pokeymon/i) { |match| match.downcase == match ? "Pokémon" : "POKÉMON" }
    
    # Handle Berry vs berry
    result.gsub!(/\bberry\b/i) do |match|
      case match
      when /^[A-Z]/ then "Berry"
      when /^[A-Z]+$/ then "BERRY"
      else "berry"
      end
    end
    
    result
  end

  def starts_with_vowel_sound?
    return false if self.empty?
    
    first_char = self[0, 1].downcase
    first_two = self[0, 2].downcase if self.length >= 2
    
    # Standard vowels
    return true if ["a", "e", "i", "o", "u"].include?(first_char)
    
    # Y is vowel-like when not followed by another vowel
    if first_char == "y" && self.length > 1
      second_char = self[1, 1].downcase
      return !["a", "e", "i", "o", "u"].include?(second_char)
    end
    
    # Handle some common exceptions
    silent_h_words = ["hour", "honor", "honest", "heir"]
    return true if silent_h_words.any? { |word| self.downcase.start_with?(word) }
    
    false
  end

  def valid_pokemon_name?
    return false if self.empty?
    return false if self.length > 20 || self.length < 2
    
    # Allow letters, spaces, hyphens, apostrophes, periods, and accented characters
    return false unless self.match?(/^[A-Za-zÀ-ÿ\s\-\'\.]+$/)
    
    # Don't allow names that are only spaces or punctuation
    return false unless self.match?(/[A-Za-zÀ-ÿ]/)
    
    # Don't allow multiple consecutive spaces or punctuation
    return false if self.match?(/([\s\-\'\.]{2,})/)
    
    # Don't start or end with spaces or punctuation
    return false if self.match?(/^[\s\-\'\.]|[\s\-\'\.]$/)
    
    true
  end

  def pluralize(count = 2)
    return self if count == 1 || count == -1 # Handle negative singular
    
    word = self.strip
    lower_word = word.downcase
    
    # Special Pokémon cases
    case lower_word
    when "pokemon", "pokémon" then return "Pokémon"
    when "pokedex", "pokédex" then return "Pokédex entries"
    when "poké ball", "poke ball", "pokeball" then return "Poké Balls"
    when "species", "fish", "sheep", "deer" then return word
    end
    
    # Handle compound words (like "Poké Ball")
    if word.include?(" ")
      words = word.split(" ")
      words[-1] = words[-1].pluralize(count)
      return words.join(" ")
    end
    
    # Standard English pluralization rules
    if lower_word.end_with?("s", "ss", "sh", "ch", "x", "z", "o")
      return word + "es"
    elsif lower_word.end_with?("f")
      return word[0...-1] + "ves"
    elsif lower_word.end_with?("fe")
      return word[0...-2] + "ves"
    elsif lower_word.end_with?("y") && word.length > 1
      second_last = word[-2, 1].downcase
      if ["a", "e", "i", "o", "u"].include?(second_last)
        return word + "s" # toy -> toys
      else
        return word[0...-1] + "ies" # berry -> berries
      end
    else
      return word + "s"
    end
  end

  def to_display_case
    self.split(/(\s+)/).map do |part|
      if part.match?(/^\s+$/) # Keep whitespace as-is
        part
      else
        part.split(/([^A-Za-z]+)/).map do |subpart|
          if subpart.match?(/^[A-Za-z]+$/) # Only capitalize letter groups
            subpart.capitalize
          else
            subpart
          end
        end.join
      end
    end.join
  end
end
#===============================================================================
# class Numeric
#===============================================================================
class Numeric
  # Turns a number into a string formatted like 12,345,678.
  def to_s_formatted
    return self.to_s.reverse.gsub(/(\d{3})(?=\d)/, '\1,').reverse
  end

  def to_word
    ret = [_INTL("zero"), _INTL("one"), _INTL("two"), _INTL("three"),
           _INTL("four"), _INTL("five"), _INTL("six"), _INTL("seven"),
           _INTL("eight"), _INTL("nine"), _INTL("ten"), _INTL("eleven"),
           _INTL("twelve"), _INTL("thirteen"), _INTL("fourteen"), _INTL("fifteen"),
           _INTL("sixteen"), _INTL("seventeen"), _INTL("eighteen"), _INTL("nineteen"),
           _INTL("twenty")]
    return ret[self] if self.is_a?(Integer) && self >= 0 && self <= ret.length
    return self.to_s
  end

#=============================================================================
# NEW METHODS
#=============================================================================
  def to_percentage(decimals = 1)
    return "#{(self * 100).round(decimals)}%"
  end
  
  def to_time_string
    total_seconds = self.to_i
    return "0s" if total_seconds <= 0
    
    hours = total_seconds / 3600
    minutes = (total_seconds % 3600) / 60
    seconds = total_seconds % 60
    
    parts = []
    parts << "#{hours}h" if hours > 0
    parts << "#{minutes}m" if minutes > 0 || (hours > 0 && seconds > 0)
    parts << "#{seconds}s" if seconds > 0 || parts.empty?
    
    parts.join(" ")
  end
  
  def to_ordinal
    num = self.to_i
    return num.to_s if num <= 0
    
    case num % 100
    when 11, 12, 13
      "#{num}th"
    else
      case num % 10
      when 1 then "#{num}st"
      when 2 then "#{num}nd" 
      when 3 then "#{num}rd"
      else "#{num}th"
      end
    end
  end
  
  def to_roman
    num = self.to_i
    return "" if num <= 0 || num >= 4000
    
    values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    literals = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
    
    result = ""
    values.each_with_index do |value, i|
      while num >= value
        result += literals[i]
        num -= value
      end
    end
    result
  end
  
  def clamp(min_val, max_val)
    return min_val if self < min_val
    return max_val if self > max_val
    return self
  end
end
#===============================================================================
# class Array
#===============================================================================
class Array
  def ^(other)   # xor of two arrays
    return (self | other) - (self & other)
  end

  def swap(val1, val2)
    index1 = self.index(val1)
    index2 = self.index(val2)
    self[index1] = val2
    self[index2] = val1
  end
end

#===============================================================================
# class Hash
#===============================================================================
class Hash
  def deep_merge(hash)
    merged_hash = self.clone
    merged_hash.deep_merge!(hash) if hash.is_a?(Hash)
    return merged_hash
  end

  def deep_merge!(hash)
    # failsafe
    return unless hash.is_a?(Hash)
    hash.each do |key, val|
      if self[key].is_a?(Hash)
        self[key].deep_merge!(val)
      else
        self[key] = val
      end
    end
  end
end

#===============================================================================
# module Enumerable
#===============================================================================
module Enumerable
  def transform
    ret = []
    self.each { |item| ret.push(yield(item)) }
    return ret
  end
end

#===============================================================================
# class File
#===============================================================================
class File
  # Copies the source file to the destination path.
  def self.copy(source, destination)
    data = ""
    t = Time.now
    File.open(source, "rb") do |f|
      loop do
        r = f.read(4096)
        break if !r
        if Time.now - t > 1
          Graphics.update
          t = Time.now
        end
        data += r
      end
    end
    File.delete(destination) if File.file?(destination)
    f = File.new(destination, "wb")
    f.write data
    f.close
  end

  # Copies the source to the destination and deletes the source.
  def self.move(source, destination)
    File.copy(source, destination)
    File.delete(source)
  end
end

#===============================================================================
# class Color
#===============================================================================
class Color
  # alias for old constructor
  alias init_original initialize unless self.private_method_defined?(:init_original)

  # New constructor, accepts RGB values as well as a hex number or string value.
  def initialize(*args)
  	pbPrintException("Wrong number of arguments! At least 1 is needed!") if args.length < 1
  	if args.length == 1
      if args.first.is_a?(Fixnum)
        hex = args.first.to_s(16)
      elsif args.first.is_a?(String)
        try_rgb_format = args.first.split(",")
        return init_original(*try_rgb_format.map(&:to_i)) if try_rgb_format.length.between?(3, 4)
        hex = args.first.delete("#")
      end
      pbPrintException("Wrong type of argument given!") if !hex
      r = hex[0...2].to_i(16)
      g = hex[2...4].to_i(16)
      b = hex[4...6].to_i(16)
  	elsif args.length == 3
      r, g, b = *args
  	end
  	return init_original(r, g, b) if r && g && b
  	return init_original(*args)
  end

  # Returns this color as a hex string like "#RRGGBB".
  def to_hex
  	r = sprintf("%02X", self.red)
  	g = sprintf("%02X", self.green)
  	b = sprintf("%02X", self.blue)
  	return ("#" + r + g + b).upcase
  end

  # Returns this color as a 24-bit color integer.
  def to_i
  	return self.to_hex.delete("#").to_i(16)
  end

  # Converts the provided hex string/24-bit integer to RGB values.
  def self.hex_to_rgb(hex)
    hex = hex.delete("#") if hex.is_a?(String)
  	hex = hex.to_s(16) if hex.is_a?(Numeric)
  	r = hex[0...2].to_i(16)
  	g = hex[2...4].to_i(16)
  	b = hex[4...6].to_i(16)
  	return r, g, b
  end

  # Parses the input as a Color and returns a Color object made from it.
  def self.parse(color)
    case color
    when Color
      return color
    when String, Numeric
      return Color.new(color)
    end
    # returns nothing if wrong input
    return nil
  end

  # Returns color object for some commonly used colors
  def self.red;     return Color.new(255,   0,   0); end
  def self.green;   return Color.new(  0, 255,   0); end
  def self.blue;    return Color.new(  0,   0, 255); end
  def self.black;   return Color.new(  0,   0,   0); end
  def self.white;   return Color.new(255, 255, 255); end
  def self.yellow;  return Color.new(255, 255,   0); end
  def self.magenta; return Color.new(255,   0, 255); end
  def self.teal;    return Color.new(  0, 255, 255); end
  def self.orange;  return Color.new(255, 155,   0); end
  def self.purple;  return Color.new(155,   0, 255); end
  def self.brown;   return Color.new(112,  72,  32); end
#=============================================================================
# NEW METHODS
#=============================================================================
  def self.type_color(type_symbol)
    type_colors = {
      normal:    [168, 168, 120], fire:      [240, 128, 48],
      water:     [104, 144, 240], electric:  [248, 208, 48],
      grass:     [120, 200, 80],  ice:       [152, 216, 216],
      fighting:  [192, 48, 40],   poison:    [160, 64, 160],
      ground:    [224, 192, 104], flying:    [168, 144, 240],
      psychic:   [248, 88, 136],  bug:       [168, 184, 32],
      rock:      [184, 160, 56],  ghost:     [112, 88, 152],
      dragon:    [112, 56, 248],  dark:      [112, 88, 72],
      steel:     [184, 184, 208], fairy:     [238, 153, 172]
    }
    
    rgb = type_colors[type_symbol.to_s.downcase.to_sym]
    return Color.new(*rgb) if rgb
    return Color.new(128, 128, 128) # Unknown type - neutral gray
  end

  def self.stat_color(stat_symbol)
    case stat_symbol.to_s.downcase.to_sym
    when :hp, :hitpoints     then Color.new(255, 89, 89)   # Red
    when :attack, :atk       then Color.new(255, 158, 89)  # Orange
    when :defense, :def      then Color.new(255, 206, 89)  # Yellow
    when :spatk, :spa        then Color.new(137, 207, 240) # Light Blue
    when :spdef, :spd        then Color.new(154, 255, 154) # Light Green
    when :speed, :spe        then Color.new(255, 154, 255) # Pink
    else Color.new(200, 200, 200) # Default gray
    end
  end

  def self.rarity_color(rarity_level)
    case rarity_level.to_i
    when 0, 1 then Color.new(157, 157, 157) # Common (gray)
    when 2    then Color.new(30, 255, 0)    # Uncommon (green)
    when 3    then Color.new(0, 112, 255)   # Rare (blue)
    when 4    then Color.new(163, 53, 238)  # Epic (purple)
    when 5    then Color.new(255, 128, 0)   # Legendary (orange)
    else Color.new(255, 215, 0)             # Mythical (gold)
    end
  end

  def self.nature_stat_color(change_value)
    case change_value
    when 10   then Color.new(255, 89, 89)   # Boosted (red)
    when -10  then Color.new(89, 89, 255)   # Lowered (blue)  
    else Color.new(255, 255, 255)           # Neutral (white)
    end
  end

  def self.get_nature_stat_colors(nature_id)
    nature = GameData::Nature.get(nature_id)
    colors = {
      :ATTACK => Color.nature_stat_color(0),
      :DEFENSE => Color.nature_stat_color(0),
      :SPECIAL_ATTACK => Color.nature_stat_color(0),
      :SPECIAL_DEFENSE => Color.nature_stat_color(0),
      :SPEED => Color.nature_stat_color(0)
    }
  
    nature.stat_changes.each do |stat, change|
      colors[stat] = Color.nature_stat_color(change)
    end
  
    return colors
  end

  def self.status_color(status)
    case status.to_s.downcase.to_sym
    when :burn, :brn     then Color.new(238, 129, 48)   # Fire orange
    when :freeze, :frz   then Color.new(152, 216, 216)  # Ice blue  
    when :paralysis, :par then Color.new(247, 208, 44)  # Electric yellow
    when :poison, :psn   then Color.new(160, 64, 160)   # Poison purple
    when :sleep, :slp    then Color.new(120, 160, 240)  # Sleep blue
    when :confusion      then Color.new(248, 88, 136)   # Psychic pink
    when :fainting, :fnt then Color.new(112, 88, 72)    # Dark gray
    else Color.new(200, 200, 200) # Default
    end
  end

  # Lighten a color by a percentage (0.0 to 1.0)
  def lighten(amount = 0.2)
    amount = amount.clamp(0.0, 1.0)
    new_red = (self.red + (255 - self.red) * amount).round.clamp(0, 255)
    new_green = (self.green + (255 - self.green) * amount).round.clamp(0, 255)
    new_blue = (self.blue + (255 - self.blue) * amount).round.clamp(0, 255)
    return Color.new(new_red, new_green, new_blue)
  end
  
  # Darken a color by a percentage (0.0 to 1.0)
  def darken(amount = 0.2)
    amount = amount.clamp(0.0, 1.0)
    new_red = (self.red * (1.0 - amount)).round.clamp(0, 255)
    new_green = (self.green * (1.0 - amount)).round.clamp(0, 255)
    new_blue = (self.blue * (1.0 - amount)).round.clamp(0, 255)
    return Color.new(new_red, new_green, new_blue)
  end
  
  # Mix two colors together (0.0 = all first color, 1.0 = all second color)
  def mix_with(other_color, ratio = 0.5)
    ratio = ratio.clamp(0.0, 1.0)
    other_color = Color.parse(other_color)
    return self if other_color.nil?
    
    new_red = (self.red * (1.0 - ratio) + other_color.red * ratio).round
    new_green = (self.green * (1.0 - ratio) + other_color.green * ratio).round
    new_blue = (self.blue * (1.0 - ratio) + other_color.blue * ratio).round
    
    return Color.new(new_red, new_green, new_blue)
  end
  
  # Get complementary color (opposite on color wheel)
  def complement
    return Color.new(255 - self.red, 255 - self.green, 255 - self.blue)
  end
  
  # Check if color is considered "dark" (useful for text contrast)
  def dark?
    # Using luminance calculation
    luminance = (0.299 * self.red + 0.587 * self.green + 0.114 * self.blue)
    return luminance < 128
  end
  
  # Get appropriate text color (black or white) for this background
  def text_color
    return self.dark? ? Color.white : Color.black
  end
  
  # Convert to grayscale
  def to_grayscale
    gray_value = (0.299 * self.red + 0.587 * self.green + 0.114 * self.blue).round
    return Color.new(gray_value, gray_value, gray_value)
  end
  
  # Alpha blend with another color
  def alpha_blend(background_color, alpha = 0.5)
    alpha = alpha.clamp(0.0, 1.0)
    background_color = Color.parse(background_color)
    return self if background_color.nil?
    
    # Alpha blending formula: result = foreground * alpha + background * (1 - alpha)
    new_red = (self.red * alpha + background_color.red * (1.0 - alpha)).round
    new_green = (self.green * alpha + background_color.green * (1.0 - alpha)).round
    new_blue = (self.blue * alpha + background_color.blue * (1.0 - alpha)).round
    
    return Color.new(new_red, new_green, new_blue)
  end
  
  # Additional common colors
  def self.gold;       return Color.new(255, 215, 0);   end
  def self.silver;     return Color.new(192, 192, 192); end
  def self.bronze;     return Color.new(205, 127, 50);  end
  def self.pink;       return Color.new(255, 192, 203); end
  def self.lime;       return Color.new(50, 205, 50);   end
  def self.indigo;     return Color.new(75, 0, 130);    end
  def self.violet;     return Color.new(138, 43, 226);  end
  def self.crimson;    return Color.new(220, 20, 60);   end
  def self.navy;       return Color.new(0, 0, 128);     end
  def self.maroon;     return Color.new(128, 0, 0);     end
  def self.olive;      return Color.new(128, 128, 0);   end
  def self.gray;       return Color.new(128, 128, 128); end
  def self.grey;       return Color.gray;               end
end
#===============================================================================
# Wrap code blocks in a class which passes data accessible as instance variables
# within the code block.
#
# wrapper = CallbackWrapper.new { puts @test }
# wrapper.set(test: "Hi")
# wrapper.execute  #=>  "Hi"
#===============================================================================
class CallbackWrapper
  @params = {}

  def initialize(&block)
    @code_block = block
  end

  def execute(given_block = nil, *args)
    execute_block = given_block || @code_block
    @params.each do |key, value|
      args.instance_variable_set("@#{key.to_s}", value)
    end
    args.instance_eval(&execute_block)
  end

  def set(params = {})
    @params = params
  end
end

#===============================================================================
# Kernel methods
#===============================================================================
def rand(*args)
  Kernel.rand(*args)
end

class << Kernel
  alias oldRand rand unless method_defined?(:oldRand)
  def rand(a = nil, b = nil)
    if a.is_a?(Range)
      lo = a.min
      hi = a.max
      return lo + oldRand(hi - lo + 1)
    elsif a.is_a?(Numeric)
      if b.is_a?(Numeric)
        return a + oldRand(b - a + 1)
      else
        return oldRand(a)
      end
    elsif a.nil?
      return oldRand(b)
    end
    return oldRand
  end
end

def nil_or_empty?(string)
  return string.nil? || !string.is_a?(String) || string.size == 0
end
