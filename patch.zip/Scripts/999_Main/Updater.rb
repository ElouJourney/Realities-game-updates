
module Updater
  @@available_version = nil
  @@log = ''

  # --- Logging ---
  def self.log(msg)
    @@log << msg.to_s + "\n"
  end

  def self.log_error(e)
    self.log("ERROR: #{e.class} - #{e.message}\n#{e.backtrace.join("\n") if e.respond_to?(:backtrace)}")
    begin
      File.open(File.join(Dir.pwd, 'updater.log'), 'ab') { |f| f.write(@@log) }
    rescue
      # ignore write errors
    end
  end

  # --- Simple UI helpers (use Essentials UI if available) ---
  def self.msg(text)
    if defined?(Kernel.pbMessage)
      Kernel.pbMessage(text)
    else
      puts text
    end
  end

  def self.ask_yes_no(text)
    if defined?(Kernel.pbConfirmMessage)
      Kernel.pbConfirmMessage(text)
    else
      print(text + " (y/n): ")
      STDIN.gets.strip.downcase.start_with?('y')
    end
  end

  def self.enter_text(prompt, maxlen = 20)
    if defined?(Kernel.pbEnterText)
      Kernel.pbEnterText(prompt, 0, maxlen)
    else
      print(prompt + ": ")
      STDIN.gets.strip
    end
  end

  # --- Version check ---
  def self.initialize_available_version
    self.log "Initializing available version"
    begin
      require 'net/http'
      require 'uri'

      return unless defined?(VERSION_URL) && VERSION_URL && VERSION_URL.strip != ''

      uri = URI(VERSION_URL)
      Net::HTTP.start(uri.host, uri.port, :use_ssl => uri.scheme == 'https') do |http|
        http.open_timeout = 5
        http.read_timeout = 5
        req = Net::HTTP::Get.new(uri)
        res = http.request(req)
        if res.is_a?(Net::HTTPSuccess)
          version_string = res.body.strip
          if version_string =~ /^\d+(?:\.\d+)*$/
            @@available_version = version_string
            self.log "Detected remote version #{version_string}"
            return
          else
            self.log "Invalid remote version string #{version_string.inspect}"
          end
        else
          self.log "Unable to get latest game version (http code #{res.code})"
        end
      end
    rescue => e
      self.log 'Unknown error when getting latest version'
      self.log_error e
    end
  end

  def self.get_available_version
    @@available_version
  end

  def self.version_array(v)
    v.split('.').map { |s| s.to_i }
  end

  # returns: 0 invalid, 1 local newer, 2 up to date, 3 patch update, 4 major update
  def self.get_version_status
    return 0 if @@available_version.nil?
    return 0 unless defined?(GAMEVERSION) && GAMEVERSION =~ /^\d+(?:\.\d+)*$/
    return 0 unless @@available_version =~ /^\d+(?:\.\d+)*$/

    lv = version_array(GAMEVERSION)
    rv = version_array(@@available_version)
    maxlen = [lv.length, rv.length].max
    (0...maxlen).each do |i|
      a = lv[i] || 0
      b = rv[i] || 0
      return 1 if a > b
      return 3 if b > a && (i == (maxlen - 1) || (lv[0..(i)].join('.') == rv[0..(i)].join('.')))
      return 4 if b > a
    end
    return 2
  end

  # --- Download helpers ---
  def self.download_file(url, dest, authorization = nil)
    self.log "Downloading #{url} -> #{dest}"
    begin
      require 'net/http'
      require 'uri'

      uri = URI(url)
      Net::HTTP.start(uri.host, uri.port, :use_ssl => uri.scheme == 'https') do |http|
        req = Net::HTTP::Get.new(uri)
        if authorization && authorization != ''
          req['Authorization'] = "Basic #{authorization}"
        end
        http.request(req) do |res|
          unless res.is_a?(Net::HTTPSuccess)
            raise "HTTP #{res.code} for #{url}"
          end
          total = res['content-length'].to_i
          progress = 0
          File.open(dest, 'wb') do |f|
            res.read_body do |chunk|
              f.write(chunk)
              progress += chunk.length
              # (optional) update progress in UI
            end
          end
          return true
        end
      end
    rescue => e
      self.log 'Download failed'
      self.log_error e
      return false
    end
  end

  def self.sha256_of_file(path)
    begin
      require 'digest'
      Digest::SHA2.file(path).hexdigest
    rescue
      nil
    end
  end

  def self.verify_checksum(file, expected_hex)
    return true if expected_hex.nil? || expected_hex.strip == ''
    actual = sha256_of_file(file)
    return false if actual.nil?
    actual.downcase == expected_hex.strip.downcase
  end

  # --- Apply patch ---
  def self.apply_patch(zip_path, directory = '.')
    self.log "Applying patch #{zip_path} to #{directory}"
    begin
      require 'fileutils'
      begin
        require 'zip'
        Zip::File.open(zip_path) do |zip_file|
          zip_file.each do |f|
            path = File.join(directory, f.name)
            FileUtils.mkdir_p(File.dirname(path))
            zip_file.extract(f, path) { true }
          end
        end
      rescue LoadError
        # fallback to system unzip if available
        if system("unzip -o #{zip_path.inspect} -d #{directory.inspect} >NUL 2>&1") || system("unzip -o #{zip_path.inspect} -d #{directory.inspect}")
          # succeeded
        else
          raise 'No rubyzip and system unzip failed or unavailable'
        end
      end
      return true
    rescue => e
      self.log 'Unable to apply patch'
      self.log_error e
      return false
    ensure
      begin; File.delete(zip_path); rescue; end
    end
  end

  # --- Authorization ---
  def self.handle_authorization
    authorization = ''
    if defined?(PATCH_USER) && PATCH_USER && PATCH_USER != ''
      password = enter_text('Password?')
      begin
        require 'base64'
        authorization = Base64.encode64("#{PATCH_USER}:#{password}").strip
      rescue
        authorization = ''
      end
    end
    authorization
  end

  # --- High-level flows ---
  def self.handle_patch_update
    if ask_yes_no("A patch (#{@@available_version}) is available. Download and apply now?")
      auth = handle_authorization
      # optional checksum fetch
      checksum = nil
      if defined?(CHECKSUM_URL) && CHECKSUM_URL && CHECKSUM_URL.strip != ''
        begin
          require 'net/http'
          require 'uri'
          u = URI(CHECKSUM_URL)
          r = Net::HTTP.get_response(u)
          checksum = r.body.strip if r.is_a?(Net::HTTPSuccess)
        rescue => e
          checksum = nil
        end
      end

      unless download_file(PATCH_URL, 'patch.zip', auth)
        msg('Patch download failed.')
        return
      end

      if checksum && !verify_checksum('patch.zip', checksum)
        msg('Checksum verification failed. Aborting.')
        return
      end

      # Backup (simple: move patch backup if desired) -- user can expand
      msg('Applying patch...')
      if apply_patch('patch.zip', '.')
        msg('Your game has been updated. The application will exit so changes can apply.')
        # Exit so files reload (RGSS exit)
        exit
      else
        msg('Failed to apply patch.')
      end
    end
  end

  def self.handle_major_update
    msg("You're playing #{GAMEVERSION}. Version #{@@available_version} is a major release and must be installed manually.")
  end

  def self.handle_update_check
    # Wait briefly for initialize to finish if running in background (optional)
    100.times do
      break if @@available_version != nil
      sleep(0.01)
    end
    status = get_version_status
    case status
    when 0
      msg('Unable to determine version info.')
    when 1
      msg('Your local version appears newer than remote. No action taken.')
    when 2
      msg('Your game is up to date.')
    when 3
      handle_patch_update
    when 4
      handle_major_update
    end
  end
end

# Start check in background (non-blocking)
begin
  Thread.new { Updater.initialize_available_version }
rescue
  # If threads not available, call during startup manually
end
