def pbHasSixFlowerPokemon?
  count = 0
  $player.party.each do |pkmn|
    next if !pkmn
    species_data = GameData::Species.get(pkmn.species)
    if species_data.flags && species_data.flags.include?("Flower")
      count += 1
    end
  end
  return count >= 6
end

def pbHasSixOBONPokemon?
  count = 0
  $player.party.each do |pkmn|
    next if !pkmn
    species_data = GameData::Species.get(pkmn.species)
    if species_data.flags && species_data.flags.include?("OBON")
      count += 1
    end
  end
  return count >= 6
end

def pbHasSixMartialArtsPokemon?
  count = 0
  $player.party.each do |pkmn|
    next if !pkmn
    species_data = GameData::Species.get(pkmn.species)
    if species_data.flags && species_data.flags.include?("MartialArts")
      count += 1
    end
  end
  return count >= 6
end

def pbPerfectIVs(pkmn, iv_value = 31)
  return if !pkmn
  GameData::Stat.each_main do |s|
    pkmn.iv[s.id] = iv_value
  end
end


def pbGeneticsDoctorAction(choice)
  # Choose a Pokemon
  pbChoosePokemon(1, 3) # Stores choice in Variable 1
  return if $game_variables[1] < 0 # They canceled
  
  pkmn = $player.party[$game_variables[1]]
  
  case choice
  when :perfect_all
    pkmn.iv[:HP] = 31
    pkmn.iv[:ATTACK] = 31
    pkmn.iv[:DEFENSE] = 31
    pkmn.iv[:SPECIAL_ATTACK] = 31
    pkmn.iv[:SPECIAL_DEFENSE] = 31
    pkmn.iv[:SPEED] = 31
  when :perfect_hp
    pkmn.iv[:HP] = 31
  when :perfect_atk
    pkmn.iv[:ATTACK] = 31
  when :perfect_def
    pkmn.iv[:DEFENSE] = 31
  when :perfect_spatk
    pkmn.iv[:SPECIAL_ATTACK] = 31
  when :perfect_spdef
    pkmn.iv[:SPECIAL_DEFENSE] = 31
  when :perfect_speed
    pkmn.iv[:SPEED] = 31
  when :zero_hp
    pkmn.iv[:HP] = 0
  when :zero_atk
    pkmn.iv[:ATTACK] = 0
  when :zero_def
    pkmn.iv[:DEFENSE] = 0
  when :zero_spatk
    pkmn.iv[:SPECIAL_ATTACK] = 0
  when :zero_spdef
    pkmn.iv[:SPECIAL_DEFENSE] = 0
  when :zero_speed
    pkmn.iv[:SPEED] = 0
  end
  pkmn.calc_stats
end